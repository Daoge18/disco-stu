function Promociones() {
  const promos = [
    { id: 1, titulo: "2x1 en entradas", detalle: "Disponible todos los jueves." },
    { id: 2, titulo: "Happy Hour", detalle: "Bebidas al 50% entre 21:00 y 23:00." },
    { id: 3, titulo: "Ladies Night", detalle: "Entrada gratis para mujeres hasta medianoche." },
  ];

  return (
    <section>
      <h2 className="neon-text mb-4">Promociones Especiales</h2>
      <div className="row">
        {promos.map((promo) => (
          <div key={promo.id} className="col-md-4 mb-3">
            <div className="card bg-secondary text-white h-100 shadow">
              <div className="card-body">
                <h5 className="card-title">{promo.titulo}</h5>
                <p className="card-text">{promo.detalle}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Promociones;
