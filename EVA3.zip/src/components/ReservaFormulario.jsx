// jsx para el formulario de reserva

import { Link } from "react-router-dom";
import { useState } from "react";
import { useAuth } from "../auth/useAuth";

function ReservaFormulario({ evento }) {
  const { usuario } = useAuth();
  const [cantidad, setCantidad] = useState(1);
  const [mensaje, setMensaje] = useState("");

  // Si no está logueado, mostrar mensaje de alerta
    if (!usuario) {
      return (
        <Link to="/login" className="alert alerta-login-reserva mt-4 text-decoration-none">
          <strong>⚠️ Loguéate para reservar.</strong>
        </Link>
      );
    }
// Si ya reservó, mostrar mensaje de alerta
  const handleSubmit = (e) => {
    e.preventDefault();
    // Validar cantidad
    if (cantidad < 1) {
      setMensaje("Por favor ingresa una cantidad válida.");
      return;
    }
// Validar usuario
    const reserva = {
      id: Date.now(),
      eventoId: evento.id,
      nombre: usuario.nombre,
      correo: usuario.email,
      cantidad,
    };
// Guardar reserva en localStorage
    const reservas = JSON.parse(localStorage.getItem("reservas")) || [];
    reservas.push(reserva);
    localStorage.setItem("reservas", JSON.stringify(reservas));

    setMensaje("¡Reserva realizada con éxito!");
  };
// Renderizar formulario de reserva
  return (
    <div className="card bg-dark text-white mt-4 p-3">
      <h4>Reserva tu entrada</h4>
      {mensaje && <p className="text-info">{mensaje}</p>}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          className="form-control mb-2"
          value={usuario.nombre}
          readOnly
        />
        <input
          type="email"
          className="form-control mb-2"
          value={usuario.email}
          readOnly
        />
        <input
          type="number"
          className="form-control mb-2"
          placeholder="Cantidad de entradas"
          min="1"
          value={cantidad}
          onChange={(e) => setCantidad(e.target.value)}
        />
        <button className="btn btn-success w-100">Reservar</button>
      </form>
    </div>
  );
}

export default ReservaFormulario;
