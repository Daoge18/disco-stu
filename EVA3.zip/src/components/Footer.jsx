function Footer() {
  return (
    <footer className="bg-dark text-white p-4 mt-5">
      <div className="container">
        <div className="row">
          <div className="col-md-4">
            <h5>Contacto</h5>
            <p>Email: contacto@discoStu.com</p>
            <p>Teléfono: +56 9 1234 5678</p>
          </div>
          <div className="col-md-4">
            <h5>Síguenos</h5>
            <a href="#" className="text-white me-2">Facebook</a>
            <a href="#" className="text-white me-2">Instagram</a>
            <a href="#" className="text-white"> X </a>
          </div>
          <div className="col-md-4">
            <h5>Ubicación</h5>
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!..."
              width="100%"
              height="150"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
            ></iframe>
          </div>
        </div>
        <hr className="border-light" />
        <p className="text-center mb-0">&copy; 2025 Disco Stu's Dance Palace</p>
      </div>
    </footer>
  );
}

export default Footer;
