function Lightbox({ imagen, onClose }) {
  return (
    <div
      className="position-fixed top-0 start-0 w-100 h-100 bg-dark bg-opacity-75 d-flex justify-content-center align-items-center"
      style={{ zIndex: 9999 }}
      onClick={onClose}
    >
      <div className="position-relative">
        <img
          src={`/img/${imagen.src}`}
          alt={imagen.titulo}
          className="img-fluid rounded"
          style={{ maxHeight: "80vh", maxWidth: "90vw" }}
        />
        <button
          className="btn btn-danger position-absolute top-0 end-0 m-2"
          onClick={onClose}
        >
          X
        </button>
      </div>
    </div>
  );
}

export default Lightbox;
