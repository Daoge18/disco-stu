import { useEffect, useState } from "react";
import { getProximoEvento } from "../utils/eventos";

function Banner() {
  const [tiempo, setTiempo] = useState(null);
  const evento = getProximoEvento();

  useEffect(() => {
    if (!evento) return;
    const target = evento.dateObj;

    const id = setInterval(() => {
      const now = new Date();
      const diff = target - now;
      if (diff <= 0) {
        setTiempo({ dias: 0, horas: 0, minutos: 0, segundos: 0 });
        clearInterval(id);
        return;
      }
      setTiempo({
        dias: Math.floor(diff / (1000 * 60 * 60 * 24)),
        horas: Math.floor((diff / (1000 * 60 * 60)) % 24),
        minutos: Math.floor((diff / (1000 * 60)) % 60),
        segundos: Math.floor((diff / 1000) % 60),
      });
    }, 1000);

    return () => clearInterval(id);
  }, [evento]);

  return (
    <div
      className="text-center p-5 banner-section"
      style={{
        background: "url('/img/disco-bg.jpg') center/cover no-repeat",
      }}
    >
      <h1 className="neon-text">¡Baila toda la noche con Disco Stu!</h1>
      {evento && tiempo && (
        <div className="mt-4">
          <h4 className="neon-subtitle">Próximo evento: {evento.titulo}</h4>
          <div className="countdown-container">
            <div className="count-box">
              <span>{tiempo.dias}</span>
              <small>Días</small>
            </div>
            <div className="count-box">
              <span>{tiempo.horas}</span>
              <small>Horas</small>
            </div>
            <div className="count-box">
              <span>{tiempo.minutos}</span>
              <small>Minutos</small>
            </div>
            <div className="count-box">
              <span>{tiempo.segundos}</span>
              <small>Segundos</small>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Banner;
