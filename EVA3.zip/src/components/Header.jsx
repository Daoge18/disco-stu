//Contiene el componente Header que se muestra en la parte superior de la aplicación
// Este componente incluye el logo, el título y los enlaces de navegación
// Importa React y los hooks necesarios
// Importa React Router para manejar la navegación


import { Link, NavLink } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
// Componente Header
// Muestra el logo, el título y los enlaces de navegación
function Header() {
  const { usuario, logout } = useAuth();

  return (
    <header className="navbar navbar-dark bg-dark px-3">
      <Link className="navbar-brand d-flex align-items-center neon-text" to="/">
        <img
          src="/img/bola-disco.gif"
          alt="Bola de Disco"
          className="logo-bola-disco"
        />
        Disco Stu's Dance Palace
      </Link>
      <nav>
        <NavLink className="nav-link d-inline text-white" to="/eventos">
          Eventos
        </NavLink>
        <NavLink className="nav-link d-inline text-white" to="/galeria">
          Galería
        </NavLink>
        <NavLink className="nav-link d-inline text-white" to="/blog">
          Blog
        </NavLink>
        {usuario ? (
          <>
            <NavLink className="nav-link d-inline text-white" to="/perfil">
              Perfil
            </NavLink>
            <button
              className="btn btn-sm btn-outline-light ms-2"
              onClick={logout}
            >
              Salir
            </button>
          </>
        ) : (
          <>
            <NavLink className="nav-link d-inline text-white" to="/login">
              Login
            </NavLink>
            <NavLink className="nav-link d-inline text-white" to="/registro">
              Registro
            </NavLink>
          </>
        )}
      </nav>
    </header>
  );
}

export default Header;
