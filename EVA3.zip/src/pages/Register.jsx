//jsx para el formulario de registro

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/useAuth";
// Importa el contexto de autenticación para manejar el registro
// Componente de registro
// Permite a los usuarios registrarse con nombre, correo y contraseña
function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [nombre, setNombre] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mensaje, setMensaje] = useState("");
// Maneja el envío del formulario
// Llama a la función de registro del contexto de autenticación
  const handleSubmit = (e) => {
    e.preventDefault();
    const ok = register(nombre, email, password);
    if (ok) {
      navigate("/perfil");
    } else {
      setMensaje("El correo ya está registrado.");
    }
  };
// Renderiza el formulario de registro
// Incluye campos para nombre, correo y contraseña
  return (
    <div className="container my-5 text-white" style={{ maxWidth: "400px" }}>
      <h2 className="neon-text mb-3">Registro</h2>
      {mensaje && <p className="text-danger">{mensaje}</p>}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          className="form-control mb-2"
          placeholder="Nombre"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
        />
        <input
          type="email"
          className="form-control mb-2"
          placeholder="Correo"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          className="form-control mb-2"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button className="btn btn-success w-100">Registrar</button>
      </form>
    </div>
  );
}

export default Register;
