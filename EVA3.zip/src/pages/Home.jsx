//jsx con la página de inicio

import EventosDestacados from "../components/EventosDestacados";
import Promociones from "../components/Promociones";
import Banner from "../components/Banner";
//funcion con banner eventos destacados y promociones
function Home() {
  return (
    <div className="bg-dark text-white">
      <Banner />
      <div className="container my-4">
        <EventosDestacados />
        <Promociones />
      </div>
    </div>
  );
}

export default Home;
