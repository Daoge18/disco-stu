// jsx con lista de eventos

import { Link } from "react-router-dom";
import { eventos } from "../utils/eventos";

// --- Fechas de eventos ---
function Eventos() {
  return (
    <div className="container my-4 text-white">
      <h2 className="neon-text mb-4">Todos los Eventos</h2>
      <div className="row">
        {eventos.map((evento) => (
          <div key={evento.id} className="col-md-4 mb-3">
            <div className="card bg-dark text-white h-100 shadow">
              <img
                src={`/img/${evento.imagen}`}
                className="card-img-top evento-img"
                alt={evento.titulo}
              />
              <div className="card-body">
                <h5 className="card-title">{evento.titulo}</h5>
                <p className="card-text">{evento.descripcion}</p>
                <p className="text-warning">
                  {evento.fecha} - {evento.hora}
                </p>
                <Link to={`/eventos/${evento.id}`} className="btn btn-primary">
                  Ver Detalle
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Eventos;
