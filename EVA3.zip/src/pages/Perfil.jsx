//jsx con perfil de usuario

import { useAuth } from "../auth/useAuth";
import { useEffect, useState } from "react";
import { eventos } from "../utils/eventos";
import { useNavigate } from "react-router-dom";

function Perfil() {
  const { usuario, logout } = useAuth();
  const navigate = useNavigate();

  const [reservas, setReservas] = useState([]);
  const [editando, setEditando] = useState(false);
  const [nombre, setNombre] = useState(usuario.nombre);
  const [password, setPassword] = useState(usuario.password || "");
  const [mensaje, setMensaje] = useState("");

  // Cargar reservas asociadas al email del usuario
  useEffect(() => {
    const todas = JSON.parse(localStorage.getItem("reservas")) || [];
    setReservas(todas.filter((r) => r.correo === usuario.email));
  }, [usuario]);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const handleGuardar = () => {
    setMensaje("");

    // Validaciones mínimas
    if (!nombre.trim()) {
      setMensaje("El nombre no puede estar vacío.");
      return;
    }

    // Cargar usuarios registrados
    const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

    // Actualizar el registro del usuario actual
    const actualizados = usuarios.map((u) =>
      u.id === usuario.id
        ? {
            ...u,
            nombre: nombre.trim(),
            // Si dejaste password vacío, preservo el anterior
            password: password.trim() ? password.trim() : u.password,
          }
        : u
    );

    // Guardar lista actualizada
    localStorage.setItem("usuarios", JSON.stringify(actualizados));

    // Actualizar usuario actual en localStorage
    const actualizado = {
      ...usuario,
      nombre: nombre.trim(),
      password: password.trim() ? password.trim() : usuario.password,
    };
    localStorage.setItem("usuario", JSON.stringify(actualizado));

    // Mostrar mensaje y salir de modo edición
    setMensaje("Perfil actualizado con éxito. 👍");
    setEditando(false);

    // Forzar refresco suave del estado visible sin recargar toda la app:
    // Navegamos al mismo perfil para que el AuthProvider re-lee localStorage en el próximo render
    // (Workaround educativo; en prod se expone un updateUser desde AuthContext).
    navigate(0); // recarga suave (Vite)
  };

  return (
    <div className="container my-4 text-white perfil-wrapper">
      <h2 className="neon-text">Perfil de {usuario.nombre}</h2>
      <p>
        <strong>Email:</strong> {usuario.email}
      </p>

      {/* ----- Bloque edición ----- */}
      {editando ? (
        <div className="card bg-dark text-white p-3 mb-4 perfil-edit-card">
          <h4 className="mb-3">Editar Perfil</h4>
          {mensaje && <p className="text-success small">{mensaje}</p>}

          <label className="form-label text-start w-100" htmlFor="perfil-nombre">
            Nombre
          </label>
          <input
            id="perfil-nombre"
            type="text"
            className="form-control mb-3"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            placeholder="Tu nombre"
          />

          <label className="form-label text-start w-100" htmlFor="perfil-email">
            Correo (no editable)
          </label>
          <input
            id="perfil-email"
            type="email"
            className="form-control mb-3"
            value={usuario.email}
            disabled
          />

          <label className="form-label text-start w-100" htmlFor="perfil-pass">
            Contraseña (deja en blanco para no cambiar)
          </label>
          <input
            id="perfil-pass"
            type="password"
            className="form-control mb-3"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Nueva contraseña (opcional)"
          />

          <div className="d-flex gap-2 justify-content-end">
            <button
              type="button"
              className="btn btn-success btn-guardar-perfil"
              onClick={handleGuardar}
            >
              Guardar
            </button>
            <button
              type="button"
              className="btn btn-secondary btn-cancelar-perfil"
              onClick={() => {
                // reset campos
                setNombre(usuario.nombre);
                setPassword("");
                setMensaje("");
                setEditando(false);
              }}
            >
              Cancelar
            </button>
          </div>
        </div>
      ) : (
        <button
          className="btn btn-warning mb-3 btn-edit-perfil"
          onClick={() => setEditando(true)}
        >
          Editar Perfil
        </button>
      )}

      {/* ----- Botón salir ----- */}
      <div className="mb-4">
        <button className="btn btn-danger btn-logout" onClick={handleLogout}>
          Salir
        </button>
      </div>

      {/* ----- Reservas ----- */}
      <h4 className="mt-4">Mis Reservas</h4>
      {reservas.length === 0 ? (
        <p>No tienes reservas.</p>
      ) : (
        <ul className="list-group mt-3 perfil-reservas-lista">
          {reservas.map((r) => {
            const evento = eventos.find((e) => e.id === r.eventoId);
            return (
              <li
                key={r.id}
                className="list-group-item bg-dark text-white perfil-reserva-item"
              >
                <strong>{evento ? evento.titulo : `Evento #${r.eventoId}`}</strong>
                <span className="ms-2">/ Cantidad: {r.cantidad}</span>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

export default Perfil;
