import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/useAuth";

function Login() {
  const { usuario, login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mensaje, setMensaje] = useState("");
  const [loading, setLoading] = useState(false);

  // Redirigir automáticamente si ya está logueado
  useEffect(() => {
    if (usuario) {
      navigate("/perfil");
    }
  }, [usuario, navigate]);

  const handleSubmit = (e) => {
    e.preventDefault();
    setMensaje("");

    if (!email || !password) {
      setMensaje("Por favor completa todos los campos.");
      return;
    }

    setLoading(true);
    const ok = login(email, password);
    setLoading(false);

    if (ok) {
      navigate("/perfil");
    } else {
      setMensaje("Correo o contraseña incorrectos.");
      setPassword(""); // Limpia el password
    }
  };

  if (usuario) return null;

  return (
    <div className="container my-5 text-white" style={{ maxWidth: "400px" }}>
      <h2 className="neon-text mb-3">Iniciar Sesión</h2>
      {mensaje && <p className="text-danger">{mensaje}</p>}
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          className="form-control mb-2"
          placeholder="Correo"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          className="form-control mb-2"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button className="btn btn-primary w-100" disabled={loading}>
          {loading ? "Entrando..." : "Entrar"}
        </button>
      </form>
    </div>
  );
}

export default Login;
