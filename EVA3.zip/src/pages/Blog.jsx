// jsx con lista de blog posts

import { Link } from "react-router-dom";
import { blogPosts } from "../data/blog";
// funcion con blog posts
function Blog() { 
  return ( 
    <div className="container my-4 text-white">
      <h2 className="neon-text mb-4">Blog de Disco Stu</h2>
      <div className="row">
        {blogPosts.map((post) => (
          <div key={post.id} className="col-md-4 mb-3">
            <div className="card bg-dark text-white h-100 shadow">
              <img
                src={`/img/${post.imagen}`}
                className="card-img-top"
                alt={post.titulo}
              />
              <div className="card-body">
                <h5 className="card-title">{post.titulo}</h5>
                <p className="card-text">{post.resumen}</p>
                <Link to={`/blog/${post.id}`} className="btn btn-primary">
                  Leer más
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Blog;
