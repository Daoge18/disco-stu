// jsx con detalles de un blog post
import { useParams } from "react-router-dom";
import { useState, useEffect } from "react";
import { blogPosts } from "../data/blog";

// --- Fechas de eventos ---
function BlogPost() {
  const { id } = useParams();
  const post = blogPosts.find((p) => p.id === parseInt(id));
  // --- Validación de ID ---
  const [likes, setLikes] = useState(0);
  const [comentarios, setComentarios] = useState([]);
  const [nuevoComentario, setNuevoComentario] = useState("");
  // --- Cargar likes y comentarios desde localStorage ---
  useEffect(() => {
    const likesStorage = JSON.parse(localStorage.getItem(`likes_${id}`)) || 0;
    const comentariosStorage = JSON.parse(localStorage.getItem(`comentarios_${id}`)) || [];
    setLikes(likesStorage);
    setComentarios(comentariosStorage);
  }, [id]);
  // --- Manejo de likes y comentarios ---
  const handleLike = () => {
    const nuevosLikes = likes + 1;
    setLikes(nuevosLikes);
    localStorage.setItem(`likes_${id}`, JSON.stringify(nuevosLikes));
  };
  // --- Manejo de nuevos comentarios ---
  const handleComentario = (e) => {
    e.preventDefault();
    if (!nuevoComentario.trim()) return;
    const nuevosComentarios = [...comentarios, nuevoComentario];
    setComentarios(nuevosComentarios);
    localStorage.setItem(`comentarios_${id}`, JSON.stringify(nuevosComentarios));
    setNuevoComentario("");
  };
  // --- Validación de post ---
  if (!post) {
    return <div className="text-white container">Artículo no encontrado.</div>;
  }
  // --- Renderizado del post ---
  return (
    <div className="container my-4 text-white">
      <h2 className="neon-text mb-3">{post.titulo}</h2>

      <img
        src={`/img/${post.imagen}`}
        alt={post.titulo}
        className="img-fluid mb-4 rounded evento-img"
      />
    
      {/* Entradilla / lead */}
      {post.resumen && <p className="blog-lead">{post.resumen}</p>}

      {/* Contenido extendido (o fallback al contenido corto) */}
      <div
        className="blog-content mb-4"
        dangerouslySetInnerHTML={{
          __html: post.contenidoExtendido || post.contenido,
        }}
      ></div>

      {/* Likes */}
      <div className="my-4">
        <button className="btn btn-outline-light me-2" onClick={handleLike}>
          👍 {likes} Me gusta
        </button>
      </div>

      {/* Comentarios */}
      <div className="card bg-dark p-3 mt-4">
        <h4 className="neon-text">Comentarios</h4>
        <form onSubmit={handleComentario}>
          <textarea
            className="form-control neon-textarea mb-2"
            placeholder="Escribe tu comentario..."
            value={nuevoComentario}
            onChange={(e) => setNuevoComentario(e.target.value)}
          ></textarea>
          <button className="btn btn-primary neon-btn w-100">Comentar</button>
        </form>
        <ul className="mt-3 list-unstyled">
          {comentarios.map((c, i) => (
            <li key={i} className="comentario-neon fade-in neon-pop">
              {c}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default BlogPost;
