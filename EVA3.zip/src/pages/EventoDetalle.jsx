/*jsx con detalles de eventos*/

import { useParams } from "react-router-dom";
import { eventos } from "../utils/eventos";
import ReservaFormulario from "../components/ReservaFormulario";
// --- Fechas de eventos ---
function EventoDetalle() {
  const { id } = useParams();
  const evento = eventos.find((e) => e.id === parseInt(id));
  // --- Validación de ID ---
  if (!evento) {
    return <div className="text-white container">Evento no encontrado.</div>;
  }
  // --- Formateo de fecha ---
  return (
    <div className="container my-4 text-white">
      <h2 className="neon-text mb-3">{evento.titulo}</h2>

      <img
        src={`/img/${evento.imagen}`}
        alt={evento.titulo}
        className="img-fluid mb-3 rounded evento-img"
      />

      <p>
        <strong>Fecha:</strong> {evento.fecha}
        <br />
        <strong>Hora:</strong> {evento.hora}
      </p>

      {/* Descripción corta */}
      <p className="evento-lead">{evento.descripcion}</p>

      {/* Detalle extendido (HTML desde eventos.js) */}
      <div
        className="evento-content mb-4"
        dangerouslySetInnerHTML={{
          __html: evento.detalleLargo || "",
        }}
      ></div>
      
      <div className="my-4">
        <h4 className="neon-text">Video Promocional</h4>
        <div className="ratio ratio-16x9">
          <iframe
            src={evento.video}
            title={`Video promocional ${evento.titulo}`}
            allowFullScreen
          ></iframe>
        </div>
      </div>

      <ReservaFormulario evento={evento} />
    </div>
  );
}

export default EventoDetalle;
