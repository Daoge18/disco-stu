//jsx con galería de fotos

import { useState } from "react";
import { galeria } from "../data/galeria";
import Lightbox from "../components/Lightbox";

function Galeria() {
  const [categoria, setCategoria] = useState("todos");
  const [imagenSeleccionada, setImagenSeleccionada] = useState(null);
  // Categorías de imágenes
  const categorias = ["todos", "conciertos", "fiestas", "tematicas"];
  // Filtrar imágenes según la categoría seleccionada
  const filtrar = (img) =>
    categoria === "todos" ? true : img.categoria === categoria;

  return (
    <div className="container my-4 text-white">
      <h2 className="neon-text mb-4">Galería de Fotos</h2>

      <div className="mb-3">
        {categorias.map((cat) => (
          <button
            key={cat}
            className={`btn me-2 ${
              categoria === cat ? "btn-primary" : "btn-outline-light"
            }`}
            onClick={() => setCategoria(cat)}
          >
            {cat.toUpperCase()}
          </button>
        ))}
      </div>

      <div className="row">
        {galeria.filter(filtrar).map((img) => (
          <div key={img.id} className="col-md-3 mb-3">
            <img
              src={`/img/${img.src}`}
              alt={img.titulo}
              className="img-fluid rounded shadow-sm gallery-img"
              style={{ cursor: "pointer" }}
              onClick={() => setImagenSeleccionada(img)}
            />
          </div>
        ))}
      </div>

      {imagenSeleccionada && (
        <Lightbox
          imagen={imagenSeleccionada}
          onClose={() => setImagenSeleccionada(null)}
        />
      )}
    </div>
  );
}

export default Galeria;
