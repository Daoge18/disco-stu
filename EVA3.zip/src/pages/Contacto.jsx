//jsx con formulario de contacto

import React, { useState } from "react";
//funcion contacto 
function Contacto() {
  const [form, setForm] = useState({
    nombre: "",
    email: "",
    mensaje: "",
  });
  const [error, setError] = useState("");
  const [exito, setExito] = useState("");
  // Maneja el cambio de los campos del formulario
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
  // Validar email
  const validarEmail = (email) => {
    return /\S+@\S+\.\S+/.test(email);
  };
  // Maneja el envío del formulario
  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");
    setExito("");
    // Validar campos
    if (!form.nombre.trim() || !form.email.trim() || !form.mensaje.trim()) {
      setError("Por favor completa todos los campos.");
      return;
    }
    if (!validarEmail(form.email)) {
      setError("Por favor ingresa un correo válido.");
      return;
    }
    setExito("Mensaje enviado con éxito. ¡Gracias por contactarnos!");
    setForm({ nombre: "", email: "", mensaje: "" });
  };
  // Renderiza el formulario de contacto
  return (
    <div className="container my-5 text-white">
      <h2 className="neon-text mb-4">Contacto</h2>

      <div className="row">
        {/* Formulario */}
        <div className="col-md-6 mb-4">
          <form onSubmit={handleSubmit}>
            {error && <div className="alert alert-danger">{error}</div>}
            {exito && <div className="alert alert-success">{exito}</div>}

            <div className="mb-3">
              <label htmlFor="nombre" className="form-label">
                Nombre
              </label>
              <input
                type="text"
                id="nombre"
                name="nombre"
                className="form-control"
                value={form.nombre}
                onChange={handleChange}
                placeholder="Tu nombre"
              />
            </div>

            <div className="mb-3">
              <label htmlFor="email" className="form-label">
                Correo electrónico
              </label>
              <input
                type="email"
                id="email"
                name="email"
                className="form-control"
                value={form.email}
                onChange={handleChange}
                placeholder="ejemplo@correo.com"
              />
            </div>

            <div className="mb-3">
              <label htmlFor="mensaje" className="form-label">
                Mensaje
              </label>
              <textarea
                id="mensaje"
                name="mensaje"
                className="form-control"
                rows="4"
                value={form.mensaje}
                onChange={handleChange}
                placeholder="Escribe tu mensaje aquí"
              ></textarea>
            </div>

            <button type="submit" className="btn btn-primary">
              Enviar
            </button>
          </form>
        </div>

        {/* Información y mapa */}
        <div className="col-md-6">
          <h4 className="neon-text">Ubicación</h4>
          <p>
            Disco Stu's Dance Palace
            <br />
            Av. Siempre Viva 1313, Springfield
          </p>
        
          <div className="mb-4">
            <iframe
              title="Mapa Disco Stu"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3269.121036879591!2d-71.21226678124918!3d-34.97863285584697!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x966457c686289e2f%3A0x3f2cd001189bff26!2sInacap%20Curic%C3%B3%20-%20Universidad%20Tecnol%C3%B3gica%20de%20Chile%2C%20Sede%20Curic%C3%B3!5e0!3m2!1ses!2scl!4v1753055339391!5m2!1ses!2scl"
              width="100%"
              height="250"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>

          <h4 className="neon-text">Síguenos en redes sociales</h4>
          <div className="social-links">
            <a
              href="https://facebook.com/discostu"
              target="_blank"
              rel="noreferrer"
              className="social-btn facebook"
            >
              Facebook
            </a>
            <a
              href="https://instagram.com/discostu"
              target="_blank"
              rel="noreferrer"
              className="social-btn instagram"
            >
              Instagram
            </a>
            <a
                href="https://twitter.com/discostu"
                target="_blank"
                rel="noreferrer"
                className="social-btn x-btn"
            >
            X
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Contacto;
