/**
 * App.jsx
 * @descripcion Este archivo contiene la estructura principal de la aplicación web "Disco Stu's Dance Palace".
 * Incluye la configuración de rutas utilizando React Router, la barra de navegación (Navbar), el pie de página (Footer)
 * y la integración del contexto de autenticación para proteger rutas privadas como el perfil de usuario.
 * 
 * La aplicación permite a los usuarios navegar entre diferentes secciones como Inicio, Eventos, Galería, Blog, Contacto,
 * Login, Registro y Perfil, mostrando componentes específicos según la ruta seleccionada. Además, implementa estilos
 * personalizados y utiliza Bootstrap para el diseño responsivo.
 * 
 * @author Diego Lecaros Devia
 * @profesor David Zuñiga
 * @carrera Analista Programador
 * @año 2025
 */////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//jsx con todos los enrutes y componentes de la aplicación

import {  HashRouter as Router, Routes, Route, NavLink, Link } from "react-router-dom";
import { AuthProvider } from "./auth/AuthContext";
import PrivateRoute from "./auth/PrivateRoute";

import Home from "./pages/Home";
import Eventos from "./pages/Eventos";
import EventoDetalle from "./pages/EventoDetalle";
import Galeria from "./pages/Galeria";
import Blog from "./pages/Blog";
import BlogPost from "./pages/BlogPost";
import Contacto from "./pages/Contacto";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Perfil from "./pages/Perfil";

import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
        <Link className="navbar-brand neon-brand d-flex align-items-center" to="/">
          <img
            src="/img/bola-disco.gif"
            alt="Bola de Disco"
            className="logo-bola-disco"
          />
          Disco Stu's Dance Palace
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNavAlt"
          aria-controls="navbarNavAlt"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="navbarNavAlt">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <NavLink
                to="/"
                end
                className={({ isActive }) =>
                  "nav-link neon-nav-link" + (isActive ? " active" : "")
                }
              >
                Inicio
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/eventos"
                className={({ isActive }) =>
                  "nav-link neon-nav-link" + (isActive ? " active" : "")
                }
              >
                Eventos
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/galeria"
                className={({ isActive }) =>
                  "nav-link neon-nav-link" + (isActive ? " active" : "")
                }
              >
                Galería
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/blog"
                className={({ isActive }) =>
                  "nav-link neon-nav-link" + (isActive ? " active" : "")
                }
              >
                Blog
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/contacto"
                className={({ isActive }) =>
                  "nav-link neon-nav-link" + (isActive ? " active" : "")
                }
              >
                Contacto
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/login"
                className={({ isActive }) =>
                  "nav-link neon-nav-link" + (isActive ? " active" : "")
                }
              >
                Login
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/register"
                className={({ isActive }) =>
                  "nav-link neon-nav-link" + (isActive ? " active" : "")
                }
              >
                Registro
              </NavLink>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}

function Footer() {
  return (
    <footer className="bg-dark text-white py-4 mt-auto">
      <div className="container text-center">
        <p>© 2025 Disco Stu's Dance Palace. Todos los derechos reservados.</p>
        <p>
          Síguenos en{" "}
          <a
            href="https://facebook.com"
            target="_blank"
            rel="noreferrer"
            className="text-white"
          >
            Facebook
          </a>{" "}
          |{" "}
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noreferrer"
            className="text-white"
          >
            Instagram
          </a>{" "}
          |{" "}
          <a
            href="https://twitter.com"
            target="_blank"
            rel="noreferrer"
            className="text-white"
          >
            X 
          </a>
        </p>
      </div>
    </footer>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="d-flex flex-column min-vh-100 bg-black">
          <Navbar />
          <main className="flex-grow-1">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/eventos" element={<Eventos />} />
              <Route path="/eventos/:id" element={<EventoDetalle />} />
              <Route path="/galeria" element={<Galeria />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/blog/:id" element={<BlogPost />} />
              <Route path="/contacto" element={<Contacto />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route
                path="/perfil"
                element={
                  <PrivateRoute>
                    <Perfil />
                  </PrivateRoute>
                }
              />
              <Route
                path="*"
                element={
                  <div className="container text-white my-5">
                    <h2>Página no encontrada</h2>
                    <p>Lo sentimos, esta ruta no existe.</p>
                  </div>
                }
              />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
