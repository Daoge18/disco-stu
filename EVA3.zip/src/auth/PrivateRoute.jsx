// Importamos las rutas necesarias para proteger las rutas privadas
// Importamos React Router para manejar las rutas y la navegación
// Importamos el contexto de autenticación para acceder al estado del usuario


import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "./useAuth";

function PrivateRoute({ children }) {
  const { usuario } = useAuth();
  const location = useLocation();

  if (!usuario) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (location.pathname === "/login" || location.pathname === "/register") {
    return <Navigate to="/perfil" replace />;
  }

  return children;
}

export default PrivateRoute;
