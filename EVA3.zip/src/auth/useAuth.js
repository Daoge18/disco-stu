// Contexto de autenticación
// Este contexto permite manejar el estado de autenticación del usuario
// y proporciona funciones para iniciar sesión, registrarse y cerrar sesión.
// Se utiliza en toda la aplicación para proteger rutas privadas y acceder a la información del usuario.
//Al igual que AuthContext, pero con el hook useAuth para acceder al contexto
// Importa React y el hook useContext para acceder al contexto
// Se podria hacer todo en un solo archivo, pero por claridad se separa el contexto y el hook de autenticación
// Ademas Router no permite exportar el contexto directamente, por lo que se crea un archivo separado
import { useContext } from "react";
import AuthContext from "./AuthContext";

export function useAuth() {
  return useContext(AuthContext);
}
