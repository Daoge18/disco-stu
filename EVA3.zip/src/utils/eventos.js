// Utilidad interna: sumar días a la fecha actual
function addDays(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d;
}

// Formatear a YYYY-MM-DD
function toYMD(date) {
  return date.toISOString().slice(0, 10);
}

// Fechas relativas ficticias
const ev1Date = addDays(5);   // +5 días
const ev2Date = addDays(12);  // +12 días
const ev3Date = addDays(20);  // +20 días
const ev4Date = addDays(30);  // +30 días
const ev5Date = addDays(45);  // +45 días
const ev6Date = addDays(60);  // +60 días
// --- Eventos ---
// Cada evento tiene un ID único, título, fecha, hora, descripción corta y larga
export const eventos = [
  {
    id: 1,
    titulo: "Fiesta Disco Electrónica",
    fecha: toYMD(ev1Date),
    hora: "23:00",
    descripcion:
      "Ven a bailar toda la noche con los mejores DJ's electrónicos animado por nuestro querido NiTanZorron invitado especial!!!",
    detalleLargo: `
      <p>Prepárate para una noche cargada de beats electrónicos, láseres sincronizados y la pista convertida en una galaxia neón. Nuestro invitado especial <strong>NiTanZorron</strong> llega con un set exclusivo lleno de mashups disco-electro.</p>
      <h5>Line-up</h5>
      <ul>
        <li>DJ NiTanZorron (Set principal)</li>
        <li>Stu Selecta (Warm-up)</li>
        <li>Beat Sisters (After-Party)</li>
      </ul>
      <p><strong>Dress code:</strong> Brillos, metálicos, o algo con luces. Los 50 primeros con outfit neón reciben 2x1 en tragos.</p>
    `,
    imagen: "evento1.jpg",
    video: "https://www.youtube.com/embed/_u_YN5Vz3Js?si=ZlIWQUB_nYkfQg3Q",
    dateObj: ev1Date,
  },
  {
    id: 2,
    titulo: "Noche de Funk y Soul",
    fecha: toYMD(ev2Date),
    hora: "22:30",
    descripcion:
      "Disfruta los clásicos del funk y soul en vivo junto al Gran STU!!!",
    detalleLargo: `
      <p>Regresa el groove: bajos profundos, metales, voces en vivo y mucho baile. Una jornada ideal para amantes de <em>James Brown</em>, <em>Chaka Khan</em>, y el funk que hace sudar la pista.</p>
      <h5>Incluye</h5>
      <ul>
        <li>Banda tributo funk en vivo</li>
        <li>Clase rápida de pasos disco-funk (22:00 hrs)</li>
        <li>Promoción de tragos con sabor a soul</li>
      </ul>
    `,
    imagen: "evento2.jpg",
    video: "https://www.youtube.com/embed/thBbP0-Odko?si=4fqyAUdnA1THeWSq",
    dateObj: ev2Date,
  },
{
  id: 3,
  titulo: "Fiesta Temática Años 80-90",
  fecha: toYMD(ev3Date),
  hora: "23:30",
  descripcion:
    "Prepara tus hombreras y tu peinado con más laca que el pelo de un hippie!!! Ven a revivir los años 80-90 junto a las rubias más rubias de la disco!!!",
  detalleLargo: `
    <p>
      La pista de baile se convierte en una máquina del tiempo: colores neón, glitter por todos lados, y DJ Stu pasando hits que harían llorar de emoción a Vanilla Ice. 
      Si no vienes con ropa fosforescente, igual brillarás con nuestras luces psicodélicas!!! 
    </p>
    <h5>¿Qué te espera?</h5>
    <ul>
      <li>🔥 <strong>Concurso "Mejor Look 80s/90s"</strong>: Tienes pantalones de paracaídas? ¡Este es tu momento!</li>
      <li>🎤 <strong>Karaoke Pop Retro</strong>: Canta "Wannabe" de Spice Girls como si estuvieras en Londres en el 96.</li>
      <li>📼 <strong>Videos musicales vintage</strong> en pantalla gigante (¡sí, incluyendo la batalla épica de <em>¿Dónde están las rubias?</em>!).</li>
    </ul>
    <p>
      Bonus: Se dice que si bailas como Terry Crews en la batalla de "Donde están las rubias?", ¡Stu te invita un trago gratis! 😉
    </p>
  `,
  imagen: "evento3.jpg",
  video: "https://www.youtube.com/embed/kCeATNDlYoQ?si=_BvK_Snbov4-3IcF",
  dateObj: ev3Date,
},

  {
    id: 4,
    titulo: "Festival Ultra Fest",
    fecha: toYMD(ev4Date),
    hora: "20:00",
    descripcion:
      "DJs internacionales, show de luces masivo y escenarios temáticos. ¡Experiencia Ultra!",
    detalleLargo: `
      <p>La edición urbana de <strong>Ultra Fest</strong> llega a Disco Stu en formato indoor: múltiples escenarios, túnel LED, y visuales sincronizadas a 4 proyectores.</p>
      <h5>Escenarios</h5>
      <ul>
        <li>Mainstage Electro</li>
        <li>House Classics Lounge</li>
        <li>Bass Lab (subgraves garantizados)</li>
      </ul>
      <p><strong>VIP:</strong> Acceso a bar premium + merch exclusiva.</p>
    `,
    imagen: "evento4.webp",
    video: "https://www.youtube.com/embed/bjLkZOM7xg4?si=_ONxLB9nixSGsp0d",
    dateObj: ev4Date,
  },
  {
    id: 5,
    titulo: "Tomorrowland Belgium (Viewing Party)",
    fecha: toYMD(ev5Date),
    hora: "18:00",
    descripcion:
      "Transmisión especial + DJs invitados inspirados en Tomorrowland. ¡Vívelo acá!",
    detalleLargo: `
      <p>No pudiste viajar a Bélgica? Tranquilo: lo traemos a ti. Pantallas gigantes transmitiendo sets oficiales + DJs locales interpretando el espíritu Tomorrowland.</p>
      <h5>Incluye</h5>
      <ul>
        <li>Pantallas en vivo con feeds del festival</li>
        <li>Set temático 'Global Rave Anthems'</li>
        <li>Estación de maquillaje neón gratis (19:00 a 21:00)</li>
      </ul>
    `,
    imagen: "evento5.jpg",
    video: "https://www.youtube.com/embed/ViQ6JDoZ-t4?si=buKnfVhRX94WOKuc",
    dateObj: ev5Date,
  },
  {
    id: 6,
    titulo: "Lollapalooza Chile (After Oficial No Oficial 😎)",
    fecha: toYMD(ev6Date),
    hora: "16:00",
    descripcion:
      "Post show: ven con tu pulsera y entra con descuento. Mezcla de bandas, remixes y fiesta abierta.",
    detalleLargo: `
      <p>Cuando se apaga el último escenario del parque, encendemos la noche acá. ¡After Lolla en Disco Stu!</p>
      <h5>Beneficios con pulsera Lolla</h5>
      <ul>
        <li>Entrada rebajada</li>
        <li>2x1 en primera bebida</li>
        <li>Zona descanso chill al aire libre</li>
      </ul>
      <p>Set mezclando rock, indie, electrónica y sorpresas mashup de headliners.</p>
    `,
    imagen: "evento6.avif",
    video: "https://www.youtube.com/embed/zqKQjVgeKyQ?si=EwNrwY9DP1mBx2g8",
    dateObj: ev6Date,
  },
];

// --- Próximo evento ---
export function getProximoEvento() {
  const ahora = new Date();
  const futuros = eventos
    .filter((e) => e.dateObj > ahora)
    .sort((a, b) => a.dateObj - b.dateObj);
  return futuros[0] || null;
}
