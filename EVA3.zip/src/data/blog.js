// arrays con datos de todos los blogs
// identificados con id, título, resumen, contenido y una imagen
// El contenido extendido es para mostrar en la página del blog
export const blogPosts = [
  {
    id: 1,
    titulo: "Tendencias en música disco 2025",
    resumen: "Qué viene este año: remezclas retro, sintetizadores analógicos y experiencias inmersivas en vivo.",
    contenido:
      "La música disco sigue más viva que nunca. En 2025, los DJs están incorporando elementos electrónicos y mezclas retro para crear experiencias únicas en la pista de baile...",
    contenidoExtendido: `
      <p>La escena <strong>disco 2025</strong> está viviendo un renacimiento creativo. Los productores están regresando a equipos analógicos, cajas de ritmo clásicas y sintetizadores retro para recrear texturas cálidas que recuerdan los años 70 y 80, pero con la potencia del procesamiento digital moderno.</p>

      <p>Las discotecas top están incorporando <em>mapping de proyección</em>, pantallas LED sincronizadas con BPM y efectos de humo inteligentes que responden al ritmo. Esta combinación de audio clásico + tecnología moderna está atrayendo tanto a veteranos como a una nueva generación de fans.</p>

      <h5>Lo que NO te puedes perder este año:</h5>
      <ul>
        <li>Sets híbridos vinilo + digital en clubes boutique.</li>
        <li>Remezclas de Donna Summer con bajos electrónicos profundos.</li>
        <li>Experiencias VR de pistas de baile históricas.</li>
        <li>Festivales con escenarios temáticos retro-futuristas.</li>
      </ul>

      <p>Si quieres sonar actual, mezcla <strong>grooves disco</strong> con <strong>bajos house modernos</strong> y capas vocales filtradas. Y no olvides: las líneas de bajo funk siguen siendo las reinas de la pista.</p>
    `,
    imagen: "blog1.jpeg",
  },
  {
    id: 2,
    titulo: "Avicii: La leyenda del disco",
    resumen: "Aunque partió temprano, su estilo melódico sigue influyendo remezclas disco-electrónicas en todo el mundo.",
    contenido:
      "DJ Avicii es una de las figuras más reconocidas en la música electrónica. Su legado sigue inspirando a nuevos artistas y DJs...",
    contenidoExtendido: `
      <p><strong>Avicii</strong> transformó la música electrónica moderna al combinar melodías emotivas con estructuras accesibles al público masivo. Aunque no fue estrictamente un productor disco, su huella melódica cruzó géneros y hoy inspira remezclas con groove disco.</p>

      <p>Temas como <em>Levels</em> y <em>Wake Me Up</em> mostraron que una canción bailable también puede ser <strong>emocional</strong>. Esa filosofía ha sido adoptada por DJs que rescatan tracks disco clásicos, agregan drops melódicos y producen versiones elevadas para festivales.</p>

      <h5>Influencias de Avicii visibles en la escena disco actual:</h5>
      <ol>
        <li>Uso de acordes mayores brillantes sobre ritmos de 4/4.</li>
        <li>Breaks vocales emocionales antes del groove principal.</li>
        <li>Colaboraciones con cantantes fuera del circuito electrónico.</li>
        <li>Producción limpia pero con alma retro.</li>
      </ol>

      <p>Hoy, tributos en clubes disco incluyen mashups como <em>“Levels vs. Stayin' Alive”</em> y sets temáticos que celebran su legado. Si quieres rendir homenaje en tu propio set, combina un lead melódico estilo Avicii encima de un beat clásico de hi-hat disco.</p>
    `,
    imagen: "blog2.avif",
  },
  {
    id: 3,
    titulo: "Consejos de baile de Disco Stu",
    resumen: "Mueve cadera, apunta al cielo, desliza talones: pasos simples que se ven pro en la pista.",
    contenido:
      "Disco Stu comparte sus mejores trucos y pasos de baile para que puedas brillar en la pista...",
    contenidoExtendido: `
      <p>¿Crees que no sabes bailar? <strong>Disco Stu</strong> dice: “Todos saben. Algunos solo necesitan ritmo y actitud”. Vamos con pasos fáciles que cualquiera puede dominar en minutos.</p>

      <h5>Calentamiento rápido:</h5>
      <ul>
        <li>Marca el beat con los hombros.</li>
        <li>Step-touch lateral (izq-der-izq-der).</li>
        <li>Agrega cadera ligera cada 2 pasos.</li>
      </ul>

      <h5>Pasos icónicos para robar miradas:</h5>
      <ul>
        <li><strong>Point Move</strong>: Apunta con el dedo al cielo en el 4 y vuelve con estilo.</li>
        <li><strong>Spin Chill</strong>: Gira corto sobre un pie, cae con rodilla flexionada.</li>
        <li><strong>Slide Disco</strong>: Desliza planta del pie adelante y atrás marcando el bombo.</li>
      </ul>

      <p>Regla de oro: <em>“Si sonríes, bailas mejor”</em>. La energía lo es todo. Invita a alguien, forma un círculo, y deja que la pista haga el resto.</p>
    `,
    imagen: "blog3.jpeg",
  },
];
