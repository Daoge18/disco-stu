// array con datos de la galería
// Cada elemento tiene un ID, una imagen, un título y una categoría

export const galeria = [
  { id: 1, src: "galeria1.jpg", titulo: "Concierto 1", categoria: "conciertos" },
  { id: 2, src: "galeria2.jpeg", titulo: "Fiesta temática", categoria: "tematicas" },
  { id: 3, src: "galeria3.jpg", titulo: "Concierto 2", categoria: "conciertos" },
  { id: 4, src: "galeria4.jpg", titulo: "Fiesta de apertura", categoria: "fiestas" },
  { id: 5, src: "galeria5.jpg", titulo: "Fiesta disco", categoria: "fiestas" },
  { id: 6, src: "galeria6.jpg", titulo: "Temática retro", categoria: "tematicas" },
];
