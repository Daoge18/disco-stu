# 🕺 Disco Stu - Sitio Web Oficial

¡Bienvenido al universo de **Disco Stu**!  
Sumérgete en la experiencia definitiva de la música disco: eventos vibrantes, promociones exclusivas y contenido animado, todo con un diseño moderno y efectos neón.

---

## 🚀 Tecnologías Destacadas

- **React** + **Vite** (desarrollo ultrarrápido)
- **React Router DOM** (navegación fluida)
- **Bootstrap 5** (componentes responsivos)
- **CSS personalizado** (efectos neón, animaciones, dark mode)
- **LocalStorage** (likes, comentarios y reservas persistentes)
- **Google Maps Embed** (ubicación interactiva)
- **YouTube Embed** (videos en eventos destacados)

---

## ⚡ Instalación Rápida

1. **Clona el repositorio:**
   ```bash
   git clone https://github.com/daoge18/disco-stu.git
   cd disco-stu
   ```

2. **Instala las dependencias:**
   ```bash
   npm install
   ```

3. **Inicia el servidor de desarrollo:**
   ```bash
   npm run dev
   ```

4. **Abre tu navegador en:**  
   [http://localhost:5173](http://localhost:5173)

---

## 🌟 Características Principales

- **Banner animado** con cuenta regresiva al próximo evento.
- **Eventos destacados** con videos de YouTube embebidos.
- **Promociones** en tarjetas interactivas.
- **Blog dinámico** con botón "Leer más", likes y comentarios guardados.
- **Formulario de contacto** validado y mensajes dinámicos.
- **Mapa interactivo** de ubicación.
- **Redes sociales** con íconos modernos (Facebook, Instagram, X/Twitter).

---

## 🎛 Guía Rápida de Uso

- **Página Principal:**  
  Banner animado, acceso rápido a eventos y promociones.

- **Eventos:**  
  Lista de próximos eventos, detalles y videos.

- **Blog:**  
  Artículos, opción de "Leer más", likes y comentarios persistentes.

- **Contacto:**  
  Formulario validado, ubicación en mapa y enlaces a redes sociales.

---

## ✨ Autor

**Diego Lecaros Devia**  
Proyecto de práctica en desarrollo web con React + CSS personalizado.

---

## 📜 Licencia

Distribuido con fines educativos y demostrativos.

---
